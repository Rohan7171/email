package com.dao;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendEmail

{
	private static String result;

   public static void main(String[] args)
  
   { 
	   try {
	   
       System.out.println("I ma here\n");
       String to = "009Razorleaf@gmail.com";
       String from="razorleaf300@gmail.com";
       System.out.println("i am outta here\n");
       
       Properties properties = System.getProperties();
       properties.put("mail.smtp.host", "smtp.gmail.com");
       properties.put("mail.smtp.port", "465");
       properties.put("mail.smtp.ssl.enable", "true");
       properties.put("mail.smtp.auth", "true");
       
      Session session= Session.getInstance(properties, new javax.mail.Authenticator() {
          
          protected PasswordAuthentication getPasswordAuthentication() {
              return new PasswordAuthentication("razorleaf300@gmail.com","sjksiosspxtyiwrn");
          }
           
      });
      session.setDebug(true);
      
          MimeMessage message1 = new MimeMessage(session);
          
          message1.setFrom(new InternetAddress(from));
          
          message1.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
          
          message1.setSubject("lets goo!!!");
          
          String message;
		message1.setText("message");
          System.out.println("done");
          Transport.send(message1);
          System.out.println("success");
      }
      catch(MessagingException mex) {
    	  System.out.println("in catch");
    	  
          mex.printStackTrace();
      }
     
   }
}