package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Read {
	
	public static String adminAuth(String username, String password) {
        // TODO Auto-generated method stub
        
          String result = null;
		try {
            //connection
            Connection con = ConnectionFactory.getConnection();
            //preparedStatement
            PreparedStatement p = con.prepareStatement
            ("select * from mail.authenticate where username=? and password=?");
            p.setString(1, username);
            p.setString(2, password);
            ResultSet rs = p.executeQuery();
            if(rs.next())
            {
                result="exist";
            }
            else
            {
                result="notexist";
            }
            
        } catch (Exception e) {
            // TODO: handle exception
            result="notexist";
            System.out.println(e);
        }
          finally {
            return result;
        }
        
        
        
    }    
}