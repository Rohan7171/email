package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionFactory {
	public static Connection getConnection() {
        // TODO Auto-generated method stub
  Connection con = null;
try 
{
 Class.forName("com.mysql.jdbc.Driver").newInstance();
    System.out.println("loaded");
    con= DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
                System.out.println(con);    
}
catch(ClassNotFoundException | SQLException e)
{  e.printStackTrace();
    }
finally {
        return con;
    }

   }
}