package com.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMultipart;




public class ReceiveMail {



   public static void main(String[] args)
    throws SQLException, MessagingException, IOException
    {
        read();
    }



   public static String read()
    throws SQLException, MessagingException, IOException
    {
      Properties props = new Properties();
      Session session = Session.getDefaultInstance(props, null);
      Store store = session.getStore("imaps");
      store.connect("smtp.gmail.com", "razorleaf300@gmail.com","sjksiosspxtyiwrn");
      Folder inbox = store.getFolder("inbox");
      inbox.open(Folder.READ_ONLY);



     int messageCount = inbox.getMessageCount();
      System.out.println("Total Messages:- " + messageCount);



     Message[] messages = inbox.getMessages();



     System.out.println("------------------------------");



     for (int i = messages.length - 1; i >= messages.length-3 ; i--) {
          Message message = messages[i];
          System.out.println("---------------------------------");  
          System.out.println("Email Number " + (i + 1));  
          System.out.println("Subject: " + message.getSubject());
          System.out.println("Date: " + message.getReceivedDate());
          System.out.println("From: " + InternetAddress.toString(message.getFrom()));
           System.out.println("Text: " + message.getContent().toString());



     }
      inbox.close(true);
      store.close();


     return("Done");
}



}